//
//  testApp.swift
//  test
//
//  Created by Niels Spaans on 18/11/2025.
//

import SwiftUI

@main
struct testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
